﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 주차관리
{
    class Parking
    {
        public string number { get; set; }
        public DateTime inTime { get; set; }
        public DateTime outtime { get; set; }
        public int pay { get; set; }
        public int nowcar { get; set; } = 0;
        

        public int Pay(DateTime a, DateTime b)
        {
            TimeSpan ts = new TimeSpan();
            ts = b - a;
            if (ts.Minutes > 0)
                pay = (ts.Hours * 60 + ts.Minutes) / 20 * 2000 + 1500;
            else
                pay = (ts.Hours * 60 - ts.Minutes) / 20 * 2000 + 1500;

            if (pay > 15000) { pay = 15000; }
            return pay;

        }


    }
}
