﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace 주차관리
{
    public partial class Form1 : Form
    {
        List<Parking> parking = new List<Parking>();
        Parking pay = new Parking();


        private void Make_Users()
        {
            // parking XML 생성
            string usersOutput = "";
            usersOutput += "<users>\n";
            foreach (var item in parking)
            {
                usersOutput += "<parking>\n";
                usersOutput += "  <number>" + item.number + "</number>\n";
                usersOutput += "  <inTime>" + item.inTime + "</inTime>\n";
                usersOutput += "  <outtime>" + item.outtime + "</outtime>\n";
                usersOutput += "  <pay>" + item.pay + "</pay>\n";
                usersOutput += "</parking>\n";
            }
            usersOutput += "</users>";
            File.WriteAllText(@"./Users.xml", usersOutput);
        }
            public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int gogo = 0;
            for (int i = 0; i < parking.Count; i++)
            {
                if (textBox1.Text == parking[i].number)
                {
                    gogo = 1;

                }
            }
            if (gogo != 1)
            {
                parking.Add(new Parking()
                {
                    number = textBox1.Text,
                    inTime = DateTime.Now,

                });
                label4.Text = parking.Count.ToString();
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = parking;
                pay.nowcar++;
                label5.Text = pay.nowcar.ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            int total = 0;

            for (int i = 0; i < parking.Count; i++)
            {
                if (textBox1.Text == parking[i].number)
                {
                    if (parking[i].pay == 0)
                    {
                        parking[i].outtime = DateTime.Now;
                        parking[i].pay = pay.Pay(parking[i].outtime, parking[i].inTime);
                        pay.nowcar--;
                    }

                }
            }
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = parking;            
            label5.Text = pay.nowcar.ToString();
            for (int i = 0; i < parking.Count; i++)
            {
                total += parking[i].pay;
            }
            label7.Text = total.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


    }

}
